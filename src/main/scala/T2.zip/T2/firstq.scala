package T2

object firstq {

  def main(args: Array[String]): Unit = {

    var k , i , j = 2;
    var m , n = 5;
    var f = 12.0f;
    var g = 4.0f;
    var c = 'X';

    println(k + 12 * m)
    println(m / j)
    println(n % j)
    println(m/j * j)
    println(f + 10*5 +g)

    i+=1
    println(i * n)
  }
}
